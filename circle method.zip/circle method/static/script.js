document.getElementById('sendBtn').addEventListener('click', () => {
    const inputData = document.getElementById('inputData').value;

    fetch('/api/process', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ input: inputData })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('response').innerText = data.message + ": " + JSON.stringify(data.data);
    })
    .catch(error => {
        console.error('Error:', error);
    });
});