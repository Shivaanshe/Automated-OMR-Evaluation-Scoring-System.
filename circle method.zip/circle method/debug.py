from theme_1_omr_system import evaluate_image_path

result = evaluate_image_path(
    r"C:\Users\shiva\Desktop\cxvfbgn\omr_outputs\upload_09d42b3ef148443a9178c30a130bb1b4_Img1.jpeg",
    version="A",
    debug=True   
)

print("JSON saved at:", result["json_path"])
print("CSV saved at:", result["csv_path"])
print("Debug image saved at:", result["debug_path"])
