

import cv2
import numpy as np
import os
import json
import pandas as pd
from uuid import uuid4

# ---------------------- Config -----------------------------
OUTPUT_DIR = "omr_outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

SUBJECTS = ["Python", "EDA", "SQL", "Power BI", "Statistics"]
QUESTIONS_PER_SUBJECT = 20
TOTAL_QUESTIONS = 100
BLOCKS = 5
OPTS_PER_Q = 4
OPTION_LABELS = ["A", "B", "C", "D"]

# ---------------------- Answer Keys -------------------------
ANSWER_KEYS = {
    "A": [
        # Python 1–20
        ["A"],["C"],["C"],["C"],["C"],["A"],["C"],["C"],["B"],["C"],
        ["A"],["A"],["D"],["A"],["B"],["A","B","C","D"],["C"],["D"],["A"],["B"],
        # EDA 21–40
        ["A"],["D"],["B"],["A"],["C"],["B"],["A"],["B"],["D"],["C"],
        ["C"],["A"],["B"],["C"],["A"],["B"],["D"],["B"],["A"],["B"],
        # SQL 41–60
        ["C"],["C"],["C"],["B"],["B"],["A"],["C"],["B"],["D"],["A"],
        ["C"],["B"],["C"],["C"],["A"],["B"],["B"],["A"],["A","B"],["B"],
        # Power BI 61–80
        ["B"],["C"],["A"],["B"],["C"],["B"],["B"],["C"],["C"],["B"],
        ["B"],["B"],["D"],["B"],["A"],["B"],["B"],["B"],["C"],["B"],
        # Statistics 81–100
        ["A"],["B"],["C"],["B"],["C"],["B"],["B"],["B"],["A"],["B"],
        ["C"],["B"],["C"],["B"],["B"],["B"],["C"],["A"],["B"],["C"]
    ],
    "B": [
        # Python 1–20
        ["A"],["B"],["D"],["B"],["B"],["D"],["C"],["C"],["A"],["C"],
        ["A"],["B"],["D"],["C"],["C"],["A"],["C"],["B"],["D"],["C"],
        # EDA 21–40
        ["A"],["A"],["B"],["A"],["B"],["A"],["B"],["B"],["C"],["C"],
        ["B"],["C"],["B"],["C"],["A"],["A"],["A"],["B"],["B"],["A"],
        # SQL 41–60
        ["B"],["A"],["D"],["B"],["C"],["B"],["B"],["B"],["B"],["B"],
        ["C"],["A"],["C"],["A"],["C"],["C"],["B"],["A"],["B"],["C"],
        # Power BI 61–80
        ["B"],["B"],["B"],["D"],["C"],["B"],["B"],["A"],["B"],["B"],
        ["B"],["C"],["A"],["D"],["B"],["B"],["D"],["A"],["B"],["A"],
        # Statistics 81–100
        ["B"],["C"],["B"],["A"],["C"],["B"],["B"],["A"],["B"],["D"],
        ["C"],["D"],["B"],["B"],["B"],["C"],["C"],["B"],["B"],["C"]
    ]
}

# ---------------------- Helpers --------------------------------

def _read_image(path):
    """Safely read image from disk (handles some windows/unicode issues)."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Image not found: {path}")
    img = None
    try:
        arr = np.fromfile(path, dtype=np.uint8)
        if arr.size:
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    except Exception:
        img = None
    if img is None:
        img = cv2.imread(path)
    if img is None:
        raise ValueError(f"Could not read image: {path}")
    return img

def _warp_paper(img):
    """Detect the paper contour and warp top-down. Fallback: return original image."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    edged = cv2.Canny(blur, 50, 200)
    cnts, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:10]
    sheet = None
    for c in cnts:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(approx) == 4:
            sheet = approx.reshape(4,2).astype("float32")
            break
    if sheet is None:
        return img
    s = sheet.sum(axis=1)
    diff = np.diff(sheet, axis=1)
    tl = sheet[np.argmin(s)]
    tr = sheet[np.argmin(diff)]
    br = sheet[np.argmax(s)]
    bl = sheet[np.argmax(diff)]
    rect = np.array([tl, tr, br, bl], dtype="float32")
    (tl, tr, br, bl) = rect
    widthA = np.linalg.norm(br - bl)
    widthB = np.linalg.norm(tr - tl)
    maxWidth = max(int(widthA), int(widthB))
    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxHeight = max(int(heightA), int(heightB))
    dst = np.array([[0,0],[maxWidth-1,0],[maxWidth-1,maxHeight-1],[0,maxHeight-1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
    return warped

def _threshold(img, debug=False):
    """Adaptive threshold to binary mask (white = filled bubbles)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    thresh = cv2.adaptiveThreshold(blur, 255,
                                   cv2.ADAPTIVE_THRESH_MEAN_C,
                                   cv2.THRESH_BINARY_INV,
                                   blockSize=25, C=12)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    clean = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    if debug:
        cv2.imwrite(os.path.join(OUTPUT_DIR, "debug_thresh.png"), clean)
    return clean

def _detect_bubbles(gray_for_hough, dp=1.2, min_dist=20, param1=50, param2=25, min_radius=8, max_radius=28):
    """
    Detect circles via HoughCircles on a grayscale image (use blurred gray).
    Returns list of dicts: { 'center':(x,y), 'radius':r, 'bbox':(x,y,w,h) }
    """
    if gray_for_hough is None:
        return []
    if len(gray_for_hough.shape) == 3:
        gray = cv2.cvtColor(gray_for_hough, cv2.COLOR_BGR2GRAY)
    else:
        gray = gray_for_hough
    gray_blur = cv2.medianBlur(gray, 5)
    circles = cv2.HoughCircles(gray_blur, cv2.HOUGH_GRADIENT,
                               dp=dp, minDist=min_dist,
                               param1=param1, param2=param2,
                               minRadius=min_radius, maxRadius=max_radius)
    results = []
    if circles is not None:
        circles = np.round(circles[0, :]).astype("int")
        for (x, y, r) in circles:
            x1, y1 = x - r, y - r
            w, h = 2 * r, 2 * r
            results.append({"center": (int(x), int(y)), "radius": int(r), "bbox": (int(x1), int(y1), int(w), int(h))})
    return results

def _map_circles_to_grid(circles, warped_shape=None, blocks=BLOCKS, rows=QUESTIONS_PER_SUBJECT, opts=OPTS_PER_Q):
    """
    Group detected circles into a flat grid list (block-major):
      length = blocks * rows * opts
    Each entry is either a circle-dict or None.
    """
    expected = blocks * rows * opts
    h, w = (warped_shape[0], warped_shape[1]) if (warped_shape is not None and len(warped_shape) >= 2) else (0,0)
    if not circles:
        return [None] * expected
    block_w = max(1.0, w / float(blocks)) if w > 0 else None
    blocks_list = [[] for _ in range(blocks)]
    for c in circles:
        cx = c["center"][0]
        if block_w:
            bi = int(min(blocks - 1, max(0, cx // block_w)))
        else:
            bi = 0
        blocks_list[bi].append(c)
    grid = []
    for bi in range(blocks):
        bl = blocks_list[bi]
        if not bl:
            grid.extend([None] * (rows * opts))
            continue
        ys = [b["center"][1] for b in bl]
        miny, maxy = min(ys), max(ys)
        if maxy == miny:
            band_h = (h / rows) if h > 0 else 1
            base_y = 0
        else:
            band_h = (maxy - miny + 1) / float(rows)
            base_y = miny
        row_buckets = [[] for _ in range(rows)]
        for b in bl:
            cy = b["center"][1]
            r_idx = int((cy - base_y) / band_h) if band_h > 0 else 0
            r_idx = max(0, min(rows - 1, r_idx))
            row_buckets[r_idx].append(b)
        for r in range(rows):
            row_bs = row_buckets[r]
            if not row_bs:
                grid.extend([None] * opts)
                continue
            if len(row_bs) > opts:
                row_bs = sorted(row_bs, key=lambda x: x["radius"], reverse=True)[:opts]
            row_bs = sorted(row_bs, key=lambda x: x["center"][0])
            for k in range(opts):
                grid.append(row_bs[k] if k < len(row_bs) else None)

    if len(grid) < expected:
        grid.extend([None] * (expected - len(grid)))
    elif len(grid) > expected:
        grid = grid[:expected]
    return grid

def _circle_fill_fraction(thresh, circle):
    if circle is None:
        return 0.0
    mask = np.zeros_like(thresh, dtype=np.uint8)
    cx, cy = int(circle["center"][0]), int(circle["center"][1])
    r = int(circle["radius"])
    cv2.circle(mask, (cx, cy), r, 255, -1)
    filled = cv2.countNonZero(cv2.bitwise_and(thresh, thresh, mask=mask))
    area = cv2.countNonZero(mask)
    return float(filled) / float(area) if area > 0 else 0.0

def _mask_fraction(thresh, contour):
    mask = np.zeros_like(thresh, dtype=np.uint8)
    try:
        cv2.drawContours(mask, [contour], -1, 255, -1)
    except Exception:
        return 0.0
    area = cv2.countNonZero(mask)
    if area == 0:
        return 0.0
    filled = cv2.countNonZero(cv2.bitwise_and(thresh, thresh, mask=mask))
    return filled / float(area)

def _decide_marked_options(fracs, option_labels=OPTION_LABELS, abs_th=0.28, rel_th=0.70, allow_multi=True):
    
    chosen = []
    if not fracs:
        return chosen
    maxv = max(fracs)
    for i, f in enumerate(fracs):
        if f >= abs_th and (maxv == 0 or f >= rel_th * maxv):
            chosen.append(option_labels[i])
    if not chosen and maxv >= 0.22:
        chosen = [option_labels[int(np.argmax(fracs))]]
    if not allow_multi and len(chosen) > 1:
        chosen = [option_labels[int(np.argmax(fracs))]]
    return chosen

def detect_choices(fracs, option_labels=OPTION_LABELS, allow_multi=True):
    return _decide_marked_options(fracs, option_labels=option_labels, allow_multi=allow_multi)

def save_results_json_csv(result, base_name="result"):
    uid = uuid4().hex
    json_path = os.path.join(OUTPUT_DIR, f"{base_name}_{uid}.json")
    csv_path = os.path.join(OUTPUT_DIR, f"{base_name}_{uid}.csv")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    # Flatten per_question to csv-friendly
    pd.DataFrame(result["per_question"]).to_csv(csv_path, index=False)
    return json_path, csv_path

# ---------------------- Main evaluation ----------------------

def evaluate_image_path(image_path, version="A", debug=False):
    if version not in ANSWER_KEYS:
        raise ValueError(f"Unknown version: {version}")

    img = _read_image(image_path)
    warped = _warp_paper(img)
    thresh = _threshold(warped, debug=False)
    gray_for_hough = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    circles = _detect_bubbles(gray_for_hough,
                              dp=1.2, min_dist=24, param1=50, param2=24,
                              min_radius=7, max_radius=30)

    expected_count = BLOCKS * QUESTIONS_PER_SUBJECT * OPTS_PER_Q
    if len(circles) < expected_count * 0.45:
        circles = _detect_bubbles(gray_for_hough,
                                  dp=1.0, min_dist=12, param1=50, param2=18,
                                  min_radius=5, max_radius=40)
    grid_cells = _map_circles_to_grid(circles=circles, warped_shape=warped.shape,
                                      blocks=BLOCKS, rows=QUESTIONS_PER_SUBJECT, opts=OPTS_PER_Q)

    used_template = False
    if sum(1 for x in grid_cells if x is not None) < expected_count * 0.4:
        used_template = True
        H, W = thresh.shape
        block_w = W / float(BLOCKS)
        row_h = H / float(QUESTIONS_PER_SUBJECT)
        new_grid = []
        est_r = int(min(max(6, int(min(block_w / (OPTS_PER_Q * 2), row_h / 3))), 30))
        for bi in range(BLOCKS):
            for r in range(QUESTIONS_PER_SUBJECT):
                for k in range(OPTS_PER_Q):
                    x1 = int(bi * block_w + (k + 0.5) * (block_w / OPTS_PER_Q))
                    y1 = int((r + 0.5) * row_h)
                    new_grid.append({"center": (x1, y1), "radius": est_r, "bbox": (x1 - est_r, y1 - est_r, est_r*2, est_r*2)})
        grid_cells = new_grid[:expected_count]

    detected_per_question = []
    debug_vis = warped.copy()
    per_question_fracs = []

    for q in range(TOTAL_QUESTIONS):
        start = q * OPTS_PER_Q
        cells = grid_cells[start:start + OPTS_PER_Q]
        fracs = []
        for idx, c in enumerate(cells):
            if c is None:
                fracs.append(0.0)
                continue
            if "radius" in c and c["radius"] is not None:
                f = _circle_fill_fraction(thresh, c)
            else:
                x,y,w,h = c.get("bbox", (0,0,0,0))
                roi = thresh[y:y+h, x:x+w] if (h>0 and w>0) else np.zeros_like(thresh)
                total = roi.size if roi.size>0 else 1
                f = float(cv2.countNonZero(roi)) / float(total)
            fracs.append(float(f))

            if debug:
                if "center" in c and "radius" in c:
                    cx, cy = int(c["center"][0]), int(c["center"][1])
                    r = int(c["radius"])
                    color = (0,255,0) if f >= 0.28 else (0,0,255)
                    cv2.circle(debug_vis, (cx, cy), r, color, 2)
                    cv2.putText(debug_vis, f"{f:.2f}", (cx - r, cy - r - 4),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA)
                else:
                    x,y,w,h = c.get("bbox", (0,0,0,0))
                    color = (0,255,0) if f >= 0.28 else (0,0,255)
                    cv2.rectangle(debug_vis, (x,y), (x+w, y+h), color, 1)
                    cv2.putText(debug_vis, f"{f:.2f}", (x+2,y+12),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1, cv2.LINE_AA)

        per_question_fracs.append(fracs)
        chosen = _decide_marked_options(fracs, option_labels=OPTION_LABELS, abs_th=0.28, rel_th=0.70, allow_multi=True)
        detected_per_question.append(chosen)

    key = ANSWER_KEYS[version]
    per_question = []
    total_correct = 0
    for i in range(TOTAL_QUESTIONS):
        det_set = set([x.upper() for x in detected_per_question[i]])
        corr_set = set([x.upper() for x in key[i]])
        is_correct = (det_set == corr_set)
        per_question.append({
            "q": i+1,
            "detected": sorted(list(det_set)),
            "correct": sorted(list(corr_set)),
            "is_correct": bool(is_correct)
        })
        if is_correct:
            total_correct += 1

    subject_scores = {}
    for s, subj in enumerate(SUBJECTS):
        start_idx = s * QUESTIONS_PER_SUBJECT
        end_idx = start_idx + QUESTIONS_PER_SUBJECT
        subject_scores[subj] = sum(1 for j in range(start_idx, end_idx) if per_question[j]["is_correct"])

    result = {
        "per_question": per_question,
        "subject_scores": subject_scores,
        "total": int(total_correct),
        "percentage": float(total_correct) / float(TOTAL_QUESTIONS) * 100.0,
        "used_template": bool(used_template)
    }

    base = os.path.splitext(os.path.basename(image_path))[0]
    json_path, csv_path = save_results_json_csv(result, base_name=base)

    debug_path = None
    if debug:
        debug_path = os.path.join(OUTPUT_DIR, f"{base}_{uuid4().hex}_debug.jpg")
        cv2.imwrite(debug_path, debug_vis)

    return {"result": result, "json_path": json_path, "csv_path": csv_path, "debug_path": debug_path}
