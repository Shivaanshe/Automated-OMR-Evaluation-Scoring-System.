from flask import Flask, request, jsonify, send_file, render_template
import os
import werkzeug
import zipfile
from uuid import uuid4
from theme_1_omr_system import evaluate_image_path, OUTPUT_DIR

app = Flask(__name__, static_folder="static", template_folder="templates")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------- Frontend Routes ----------------------

@app.route('/')
def index():
    """Serve main index.html"""
    return render_template('index.html')


# ---------------------- API Routes ----------------------

@app.route('/evaluate', methods=['POST'])
def evaluate_api():
    """Handle OMR sheet upload and evaluation"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400

        f = request.files['file']
        version = request.form.get('version', 'A')

        # Save upload with unique ID
        unique_id = uuid4().hex
        filename = f'upload_{unique_id}_{werkzeug.utils.secure_filename(f.filename or "sheet.jpg")}'
        fname = os.path.join(OUTPUT_DIR, filename)
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        f.save(fname)

        # Run evaluation
        out = evaluate_image_path(fname, version=version, debug=False)

        return jsonify({
            'status': 'success',
            'json_path': '/' + out['json_path'].replace('\\', '/'),
            'csv_path': '/' + out['csv_path'].replace('\\', '/'),
            'result_summary': out['result']
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/download_all', methods=['GET'])
def download_all():
    """Download all results as a ZIP"""
    zip_path = os.path.join(BASE_DIR, 'all_results.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(OUTPUT_DIR):
            for fn in files:
                full = os.path.join(root, fn)
                arcname = os.path.relpath(full, BASE_DIR)
                zf.write(full, arcname)
    return send_file(zip_path, as_attachment=True)

# ---------------------- Entry Point ----------------------

if __name__ == '__main__':
    print("✅ Flask backend ready at http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
